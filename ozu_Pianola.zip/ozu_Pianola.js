//=============================================================================
//  ozu_Pianola.js 1.0
//=============================================================================

/*:
 * @author ozubon
 * @plugindesc Let's you set up a pianola/player piano, a self-playing piano!
 * @help
 * ===========================================================================
 * Setup
 * ===========================================================================
 * To make a pianola you need a parallel event.
 *
 * Step 1: Add a Wait to the event, this adjusts the tempo of the pianola.
 * The Wait defines how long a quarter note should be. So Wait set to 30
 * roughly translates to 120 bpm (allegro moderato), a very popular tempo.
 * 
 * The longer the Wait the slower the music. If you're unsure, set Wait to 30.
 *
 * Without a Wait it will be a confused, cloudy and loud ooze of sound. 
 *
 * Step 2: Use script call and enter pianola()
 * That's it! The event will now play the piano!
 *
 * Bonus: You can define a max volume, for example 50, like this: pianola(50)
 *
 * Game crashes? Make sure you have these in your audio/se/pianola folder:
 *
 * C2	C3	C#2	C#3	D2	D3	D#2	D#3
 * E2	E3	F2	F3	F#2	F#3	G2	G3
 * G#2	G#3	A2	A3	A#2	A#3	B2	B3
 * 
 *
 */
 
function pianola(maxVolume) {
	
	if (maxVolume === undefined) {
		maxVolume = 40
	};
	
	function rnd(min, max) {
		return Math.floor(Math.random() * (max - min + 1) ) + min;
	};
		
	notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
	
	if (pianola.keyOf === undefined) {
		pianola.keyOf = notes[rnd(0, 11)];
	};
	
	keyOf = pianola.keyOf;
	keyRef = 0;
	
	// This section moves the key to the beginning of the notes array: 
	
	if (keyOf === "C#") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "D") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "D#") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "E") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "F") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "F#") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "G") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "G#") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "A") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "A#") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
	if (keyOf === "B") {notes.slice(-keyRef).concat(notes.slice(0, notes.length-keyRef))}; 	keyRef++;
		
	notes.push(notes[0]);
	
	steps = 0;
	H = 1;
	W = 2;
	H3 = 3;
	W2 = 4;
	
	function step(s) {
		steps += s;
		return notes[steps];
	};
	
	//												~~~~~~~~~~~~~~ Scales ~~~~~~~~~~~~~~
	
	scale_ionian = 			[notes[0], step(W), step(W), step(H), step(W), step(W), step(W), step(H)];		steps = 0;
	scale_aeolian = 		[notes[0], step(W), step(H), step(W), step(W), step(H), step(W), step(W)];		steps = 0;
	scale_dorian  = 		[notes[0], step(W), step(H), step(W), step(W), step(W), step(H), step(W)];		steps = 0;
	scale_locrian = 		[notes[0], step(H), step(W), step(W), step(H), step(W), step(W), step(W)];		steps = 0;
	scale_lydian = 			[notes[0], step(W), step(W), step(W), step(H), step(W), step(W), step(H)];		steps = 0;
	scale_pentatonicmaj = 	[notes[0], step(W), step(W), step(H3), step(W), step(H3)];						steps = 0;
	scale_pentatonicmin = 	[notes[0], step(H3), step(W), step(W), step(H3), step(W)];						steps = 0;
	scale_melodicminor = 	[notes[0], step(W), step(H), step(W), step(W), step(W), step(W), step(H)];		steps = 0;
	scale_mixolydian = 		[notes[0], step(W), step(W), step(H), step(W), step(W), step(H), step(W)];		steps = 0;
	scale_persian = 		[notes[0], step(H), step(H3), step(H), step(H), step(W), step(H3), step(H)];		steps = 0;
	scale_phrygian = 		[notes[0], step(H), step(W), step(W), step(W), step(H), step(W), step(W)];		steps = 0;
	scale_halfdiminished = 	[notes[0], step(W), step(H), step(W), step(H), step(W), step(W), step(W)];		steps = 0;
	scale_hirajoshi = 		[notes[0], step(W2), step(W), step(H), step(W2), step(H)];						steps = 0;
	scale_insen = 			[notes[0], step(H), step(W2), step(W), step(W2), step(W)];						steps = 0;
	
	scales = 	["ionian", "aeolian", "dorian", "locrian", "lydian", "pentatonicmaj", "pentatonicmin", "melodicminor", 
				"mixolydian", "persian", "phrygian", "halfdiminished", "hirajoshi", "insen"];
	
	if (pianola.scale === undefined) {
		pianola.scale = scales[rnd(0, scales.length - 1)];
	};
	
	scale = eval("scale_" + pianola.scale);
	scale.pop();
	
	function chord() {
				//	 Major				Major 6th	 	Major6add9		 	Minor			Minor 6th		Dream
		chords =	[[0,4,7],			[0,4,7,9],		[0,4,7,9,2],		[0,3,7],		[0,3,7,9], 		[0,5,6,7],
					 [0,3,7,9,2],		[1,5,8],		[0,7],				[0,5,7],		[0,4,8], 		[0,3,6]];
				//	 Minor6add9			Neopolitan		Power				Suspended		Augmented		Diminished
		chords = chords[rnd(0,11)];
		return chords;
	};
	
	function assignKey(chordChance) {
		if (rnd(1, chordChance) == true) {
			return chord();
		} else {
			return [rnd(0, scale.length)];
		}
	};
	
	
	// This function writes the score of the song:
	
	function makeSong() {
	
		pianola.keyOf = notes[rnd(0, 11)];
		pianola.scale = scales[rnd(0, scales.length - 1)];
		pianola.song = [];
		pianola.song.length = 4 * rnd(10, 40);
		wholeChordChance = rnd(1, 10);
		halfChordChance = rnd(1, 15);
		quarterChordChance = rnd(1, 30);
		halfChance = rnd(4, 20);
		quarterChance = rnd(4, 20);
		
		for (i = 0; i < pianola.song.length; i += 4) {	// Whole notes
			pianola.song[i] = assignKey(wholeChordChance);
		};
		for (i = 0; i < pianola.song.length; i += 2) {	// Half notes
			if (rnd(1, halfChance) === 1 && pianola.song[i] === undefined) {
				pianola.song[i] = assignKey(halfChordChance);
			}
		};
		for (i = 0; i < pianola.song.length; i += 1) {	// Quarter notes
			if (rnd(1, quarterChance) === 1 && pianola.song[i] === undefined) {
				pianola.song[i] = assignKey(quarterChordChance);
			}
		};
		pianola.song.length += 24;
	};
	
	
	if (pianola.song === undefined || pianola.song.length === 0) {
		makeSong();
	};
	
	if (rnd(0,1) == true) {  // Randomizes which notes are played by which hand
		Hand1 = "2";
		Hand2 = "3";
	} else {
		Hand1 = "3";
		Hand2 = "2";
	};
	
	// This bit plays the current note, and divides chords larger than the scale to both hands:
	
	if (pianola.song[0] != undefined) {		
		for (i = 0; i < pianola.song[0].length; i++) {	
			if (scale.length  > pianola.song[0][i]) {
				noteName = "pianola/" + scale[pianola.song[0][i]] + Hand1;
				AudioManager.playSe({ name: noteName, volume: rnd(Math.round(maxVolume/4), maxVolume), pitch: 100, pan: -40 });
			} else {
				noteName = "pianola/" + scale[pianola.song[0][i] - scale.length] + Hand2;
				AudioManager.playSe({ name: noteName, volume: rnd(Math.round(maxVolume/4), maxVolume), pitch: 100, pan: 40 });
			}
		}
	};
	
	pianola.song.shift();
};